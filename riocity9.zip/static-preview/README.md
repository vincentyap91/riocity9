# Static Preview Files

This folder contains static HTML preview files for all pages of the RioCity9 application.

## 生成完全静态的 HTML（可直接打开，无需 React）

要生成可以直接在浏览器中打开的静态 HTML 文件（纯 HTML + CSS，无需 React 运行），请按照以下步骤操作：

### 步骤 1: 安装 Puppeteer

```bash
npm install puppeteer --save-dev
```

### 步骤 2: 启动开发服务器

在一个终端窗口中运行：

```bash
npm run dev
```

等待服务器启动（通常是 http://localhost:5173）

### 步骤 3: 生成静态 HTML 文件

在另一个终端窗口中运行：

```bash
npm run generate-static-html
```

或者：

```bash
node scripts/generate-static-html.js
```

### 脚本功能

这个脚本会：
- ✅ 使用 Puppeteer 访问每个路由
- ✅ 等待页面完全渲染
- ✅ 提取完全渲染的 HTML 内容
- ✅ 内联所有 CSS 样式
- ✅ 移除所有 React 脚本依赖
- ✅ 保存为独立的 HTML 文件
- ✅ 复制所有资源文件

### 生成的文件

生成后，所有 HTML 文件都可以：
- ✅ 直接在浏览器中打开
- ✅ 无需运行 React 应用
- ✅ 无需服务器
- ✅ 可以打包上传到 Google Drive
- ✅ 完全自包含（包含所有 CSS 和资源）

## File Structure

```
static-preview/
├── index.html          # Home page
├── slots.html          # Slots games
├── live-casino.html    # Live casino
├── sports.html         # Sports betting
├── fishing.html        # Fish hunt games
├── lottery.html        # Lottery games
├── poker.html          # Poker games
├── referral.html       # Referral program
├── login.html          # Login page
├── register.html       # Registration
├── ...                 # Other pages
├── assets/             # Images and other assets
└── css/                # Stylesheets
```

## Usage

1. Open any HTML file in a web browser
2. Note: Current files require the React app to be running
3. For fully static preview, use Option 1 above

## Notes

- All assets are copied from the `dist/assets` folder
- CSS files are in the `css/` subfolder
- Images and other assets are in the `assets/` subfolder
- Files are ready to be zipped and uploaded to Google Drive
